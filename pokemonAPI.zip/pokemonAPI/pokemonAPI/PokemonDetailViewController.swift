//
//  PokemonDetailViewController.swift
//  pokemonAPI
//
//  Created by Romelo Lopez on 5/8/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage
import SwiftyJSON


class PokemonDetailViewController: UIViewController {
    
    var pokemon = PokemonModel()
    var pokemonAttributes: [PokemonModel]? = []
    var number = 0
    
    @IBOutlet weak var pokemonName: UILabel!
    @IBOutlet weak var attributeLabel: UILabel!
    @IBOutlet weak var typesLabel: UILabel!
    @IBOutlet weak var heightLabel: UILabel!
    @IBOutlet weak var weightLabel: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pokemonName.text = pokemon.name?.capitalizingFirstLetter()
        fetchPokemon()
        downloadImage()
        print(number)
        print ("this pokemon name is: \(String(describing: pokemon.name!))")
        // Do any additional setup after loading the view.
    }
    
    func downloadImage(){
        
        Alamofire.request("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/\(self.number).png", method: .get).responseImage { response in
            guard response.result.value != nil else {
                print ("error getting image")
                return
            }
            if let data = response.data {
                self.image.image = UIImage(data: data)
            }
        }
    }
    
    func fetchPokemon(){
        
        Alamofire.request("https://pokeapi.co/api/v2/pokemon/\(String(describing: pokemon.name!))/").responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                let swiftyJsonVar = JSON(responseData.result.value!)
                self.pokemonAttributes = [PokemonModel]()
                
                //Get abilities and put them into a label to display
                
                if let pokemon = swiftyJsonVar["abilities"].arrayObject as? [[String : AnyObject]]{
                    for results in pokemon {
                        let newPokemon = PokemonModel()
                        if let name = results["ability"]!["name"] as? String {
                            newPokemon.attributes = name
                        }
                        self.pokemonAttributes?.append(newPokemon)
                        print(newPokemon.attributes!)
                        
                        self.attributeLabel.text = self.attributeLabel.text! + newPokemon.attributes! + "\n"
                        
                    }
                }else{
                    print("Error in fetching the NEWS JSON")
                }
                
                if let pokemon = swiftyJsonVar["types"].arrayObject as? [[String : AnyObject]]{
                    for results in pokemon {
                        let newPokemon = PokemonModel()
                        if let name = results["type"]!["name"] as? String {
                            newPokemon.attributes = name
                        }
                        self.pokemonAttributes?.append(newPokemon)
                        print(newPokemon.attributes!)
                        
                        self.typesLabel.text = self.typesLabel.text! + newPokemon.attributes! + "\n"
                        
                    }
                }else{
                    print("Error in fetching the NEWS JSON")
                }
                
                let newPokemon = PokemonModel()
                let height = swiftyJsonVar["height"].intValue
                let heightString = "\(height)"
                
                newPokemon.attributes = heightString
                self.pokemonAttributes?.append(newPokemon)
                print(newPokemon.attributes!)
                self.heightLabel.text = self.heightLabel.text! + newPokemon.attributes! + "\n"
                
                let weight = swiftyJsonVar["weight"].intValue
                let weightString = "\(weight)"
                
                newPokemon.attributes = weightString
                self.pokemonAttributes?.append(newPokemon)
                print(newPokemon.attributes!)
                self.weightLabel.text = self.weightLabel.text! + newPokemon.attributes! + "\n"
            }
        }
    }
}
