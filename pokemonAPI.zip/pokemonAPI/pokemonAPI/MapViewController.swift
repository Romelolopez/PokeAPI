//
//  MapViewController.swift
//  pokemonAPI
//
//  Created by Romelo Lopez on 5/9/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController {

    @IBOutlet weak var nintendo: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let location = "10 Rockefeller Plaza, New York, NY 10020"
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(location) { [weak self] placemarks, error in
            if let placemark = placemarks?.first, let location = placemark.location {
                let mark = MKPlacemark(placemark: placemark)
                
                if var region = self?.nintendo.region {
                    region.center = location.coordinate
                    region.span.longitudeDelta = 1.0
                    region.span.latitudeDelta = 1.0
                    self?.nintendo.setRegion(region, animated: true)
                    self?.nintendo.addAnnotation(mark)
                }
            }
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
