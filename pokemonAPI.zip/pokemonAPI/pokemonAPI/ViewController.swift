//
//  ViewController.swift
//  pokemonAPI
//
//  Created by Romelo Lopez on 5/7/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

