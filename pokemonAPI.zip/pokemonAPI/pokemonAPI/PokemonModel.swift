//
//  PokemonModel.swift
//  pokemonAPI
//
//  Created by Romelo Lopez on 5/9/19.
//  Copyright © 2019 Romelo Lopez. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireImage
import SwiftyJSON

class PokemonModel {
    
    var name: String?
    var attributes: String?
    var type: String?
    var height: String?

}

extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}
